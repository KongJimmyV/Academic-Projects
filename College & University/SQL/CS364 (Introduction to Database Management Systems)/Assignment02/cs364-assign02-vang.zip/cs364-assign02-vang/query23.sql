SELECT Name, Milliseconds / 1000 AS LengthSeconds
    FROM Track;
    