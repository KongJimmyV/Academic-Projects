import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class Scrabble {
	private static HashMap<Character, Integer> tileVals;
	private static HashMap<Character, Integer> tileNums;
	public static File words;
	public static void main(String[] args) throws FileNotFoundException {
		Scanner s = new Scanner(System.in);
		String difficulty = s.next();
		int numPlayers = s.nextInt();
		initialize(difficulty, numPlayers);
		words = new File("./src/OWL-new.txt");
		//TEST INPUT - Change testString to test different words
		ArrayList<Tile> test = new ArrayList<>();
		String testString = "ZOOGEOGRAPHICAL";
		for(int i = 0; i < testString.length(); i++) {
			Tile x = new Tile();
			x.letter = testString.charAt(i);
			test.add(x);
		}
		System.out.println(checkWord(test));
		System.out.println(getScore(test));
	}

	private static void initializeTileStack(){
		//A map that holds how many of each tile remains in the pile
		tileNums = new HashMap<>();
		//A map that holds the score value of each tile
		tileVals = new HashMap<>();
		tileVals.put(' ', 0);
		//Adds the score of each letter to the tileVals map
		for(int i = 65; i < 91; i++) {
			//A E I L N O R S T U (1-point)
			if(i == 65 || i == 69 || i == 73 || i == 76 || i == 78 || i == 79 || i == 82 || i == 83 || i == 84 || i == 85) {
				tileVals.put((char) i, 1);
			} 
			//F H V W Y (4-point)
			else if (i == 70 || i == 72 || i == 86 || i == 87 || i == 89) {
				tileVals.put((char) i, 4);
			} 
			//B C M P (3-point)
			else if (i == 66 || i == 67 || i == 77 || i == 80) {
				tileVals.put((char) i, 3);
			} 
			//D G (2-point)
			else if (i == 68 || i == 71) {
				tileVals.put((char) i, 2);
			}
			//J X (8-point)
			else if (i == 74 || i == 88) {
				tileVals.put((char) i, 8);
			} 
			//Q Z (10-point)
			else if (i == 81 || i == 90) {
				tileVals.put((char) i, 10);	
			} 
			//K (5-point)
			else {
				tileVals.put((char) i, 5);
			}
		}
		//Adds the quantity of each letter in the pile
		for(int i = 65; i < 91; i++) {
			if(i == 66 || i == 67 || i == 70 || i == 72 || i == 77 || i == 80 || i == 86 || i == 87 || i == 89) {
				tileNums.put((char) i, 2 );
			} else if (i == 74 || i == 75 || i == 81 || i == 88 || i == 90) {
				tileNums.put((char) i, 1);
			} else if (i == 68 || i == 76 || i == 83 || i == 85) {
				tileNums.put((char) i, 4);
			} else if (i == 65 || i == 73) {
				tileNums.put((char) i, 9);
			} else if (i == 69) {
				tileNums.put((char) i, 12);
			} else if (i == 71) {
				tileNums.put((char) i, 3);
			} else {
				tileNums.put((char) i, 8);
			}
		}
		tileNums.put(' ', 2);
	}
	
	private static void initialize(String difficulty, int numPlayers) {
		//Creates the maps for the number of tiles and their values
		initializeTileStack();
		int boardSize = 0;
		//TODO: Change to connect with GUI, program temporarily reads in difficulty and number of players from System.in
		if(difficulty.equals("beginner")) {
			boardSize = 11;
		} else {
			boardSize = 15;
		}
		//A 2D array of Tile objects that comprises the board
		Tile[][] board = new Tile[boardSize][boardSize];
		//Adding special score bonuses to the board
		for(int i = 0; i < boardSize; i++) {
			for(int j = 0; j < boardSize; j++) {
				board[i][j] = new Tile();
				//Starting tile
				if((i == boardSize/2) && (j == boardSize/2)) {
					board[i][j].special = "ST";
				}
				//All triple word tiles
				else if((i == 0 || i == boardSize /2 || i == (boardSize - 1)) && (j == 0 || j == boardSize /2 || j == (boardSize - 1))) {
					board[i][j].special = "TW";
				}
				//Triple and Double Letter tiles for the beginner board
				else if (boardSize == 11) {
					if((i == 1 || i == 9) && (j == 3 || j == 7)) {
						board[i][j].special = "TL";
					} else if ((i == 3 || i == 7) && (j == 1 || j == 9)) {
						board[i][j].special = "TL";
					} else if (((i == 2 || i == 8) && (j == 5)) || ((j == 2 || j == 8) && (i == 5))) {
						board[i][j].special = "DL";
					}
				}
				//Triple Letter and Double Word tiles for the challenger board
				else if (boardSize == 15) {
						int[] tripleL = {1,5,9,13};
						if((i == 1 || i == 13) && (j == 1 || j == 13)) {
							board[i][j].special = "DW";
						}
						else if(contains(tripleL, i) && (contains(tripleL, j))) {
							board[i][j].special = "TL";
						}
				} else if ((i > 0 && i < boardSize - 1) && (i == j || j == (boardSize-1) - i)) {
					board[i][j].special = "DW";
				}
				//Prints out the board for debugging purposes
				System.out.print(" [" + board[i][j].special + "] ");
			}
			//Formatting to make the board more readable
			System.out.println();
			System.out.println();
		}
	}
	
	//Helper function for adding special bonuses to tiles
	private static boolean contains(int[] arr, int val) {
		for(int i = 0; i < arr.length; i++) {
			if(arr[i] == val) {
				return true;
			}
		}
		return false;
	}
	
	//checks the validity of a word
	private static boolean checkWord(ArrayList<Tile> wordList) throws FileNotFoundException {
		boolean valid = false;
		Scanner f = new Scanner(words);
		String test = f.next();
		String word = "";
		for(int i = 0; i < wordList.size(); i++) {
			word = word + wordList.get(i).letter;
		}
		System.out.println("checkWord - " + word);
		while(f.hasNext()) {
			if(test.equals(word)) {
				valid = true;
			}
			test = f.next();
		}
		if(test.equals(word)) {
			valid = true;
		}
		f.close();
		return valid;
	}
	
	//Takes in an array list of tile objects and tallys up the score of each tile in the list
	private static int getScore(ArrayList<Tile> word) {
		int score = 0;
		boolean tripleWord = false;
		boolean doubleWord = false;
		for(int i = 0; i < word.size(); i++) {
			Tile curTile = word.get(i);
			if(curTile.special == "DL") {
				score = score + (2 * (tileVals.get(curTile.letter)));
				continue;
			} else if (word.get(i).special == "TL") {
				score = score + (3 * (tileVals.get(curTile.letter)));
				continue;
			} else if (curTile.special == "DW") {
				doubleWord = true;
			} else if (curTile.special == "TW") {
				tripleWord = true;
			}
			score = score + (tileVals.get(curTile.letter));
		}
		if(tripleWord == true) {
			score = 3 * score;
		} else if (doubleWord == true) {
			score = 2 * score;
		}
		return score;
	}
	
	//The tile object
	//Params-
	//open: whether or not the tile is occupied by a letter
	//special: the bonus points available on that tile (either DL,TL,DW or TW)
	//letter: if a letter occupies the tile, the letter is held here
	private static class Tile {
		private boolean open;
		private String special;
		private char letter;
		
		private Tile() {
			open = true;
			special = "NA";
			letter = ' ';
		}
	}
}
