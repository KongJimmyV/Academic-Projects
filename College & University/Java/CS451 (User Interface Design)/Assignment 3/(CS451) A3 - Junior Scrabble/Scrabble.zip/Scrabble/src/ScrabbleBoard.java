
public class ScrabbleBoard {
	private static String difficulty;
	public static void main (String[] args) {
		initializeBoard();
	}
	
	private static void initializeBoard() {
		if(difficulty.equals("Beginner")) {
			
		}
	}
}
