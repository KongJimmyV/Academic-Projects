-- Register New User
INSERT INTO customers (username, password, first_name, last_name, type, address, email)
VALUES ("testusername", "testpass", "Testfirst", "TestLast", "user", "123 test st, La Crosse WI, 54601", "test@test.com")

-- Filter products by name/category
SELECT *
FROM product
WHERE [column] = [identifier]
ORDER BY [column] ASC 
--or 
ORDER BY [column] DESC
	-- if price filter use, change WHERE line to
		WHERE price BETWEEN [lower_range] AND [upper_range]
	-- if "in stock" filter used, change WHERE line to
		WHERE quantity > 0
		
		
-- what to do with guest?