
int i;
int jj;
int k;
int m;
i = 3;
jj = 8;
k = 2;
m = i+jj*k;
print(m); printlines(1);
m = jj/i+k;
print(m); printlines(1);
m = k*jj%i;
print(m); printlines(1);
m = jj^k^i; //j^k^i checks right associativity
print(m); printlines(1);
