
int i;
int jj;
int k;
int m;

read(i, jj, k, m);

print(i); printspaces(1);
print(jj); printspaces(1);
print(k); printspaces(1);
print(m); printspaces(1);
printlines(1);

print(i^jj*k+m); printspaces(1);
print(m+k*i^jj); printspaces(1);
printspaces(8);

print(i); printspaces(1);
print(jj); printspaces(1);
print(k); printspaces(1);
print(m); printspaces(1);
printlines(1);
